package com.reyfree.space;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

@Mod(SpaceMod.MODID)
public class SpaceMod {
    public static final String MODID = "space";
    public static final ResourceKey<net.minecraft.world.level.Level> MOON =
        ResourceKey.create(Registries.DIMENSION, new ResourceLocation(MODID, "moon"));
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, MODID);
    public static final RegistryObject<Item> ROCKET = ITEMS.register("rocket",
        () -> new RocketItem(new Item.Properties().stacksTo(1)));

    public SpaceMod() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ITEMS.register(bus);
    }
}
