package com.reyfree.space;

import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

public class RocketItem extends Item {
    public RocketItem(Properties properties) { super(properties); }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!level.isClientSide && player instanceof ServerPlayer serverPlayer) {
            ServerLevel destination;
            if (serverPlayer.level.dimension().equals(SpaceMod.MOON)) {
                destination = serverPlayer.server.getLevel(Level.OVERWORLD);
                if (destination == null) return InteractionResultHolder.fail(stack);
                serverPlayer.sendSystemMessage(Component.literal("Regresando a la Tierra...").withStyle(ChatFormatting.AQUA));
                serverPlayer.teleportTo(destination, 0.5, destination.getHeight(net.minecraft.world.level.levelgen.Heightmap.Types.MOTION_BLOCKING, 0, 0) + 1, 0.5, serverPlayer.getYRot(), serverPlayer.getXRot());
            } else {
                destination = serverPlayer.server.getLevel(SpaceMod.MOON);
                if (destination == null) {
                    serverPlayer.sendSystemMessage(Component.literal("No se encontró la dimensión lunar. Revisa que el mod esté instalado correctamente.").withStyle(ChatFormatting.RED));
                    return InteractionResultHolder.fail(stack);
                }
                serverPlayer.sendSystemMessage(Component.literal("¡Despegando hacia la Luna!").withStyle(ChatFormatting.GOLD));
                serverPlayer.teleportTo(destination, 0.5, -58, 0.5, serverPlayer.getYRot(), serverPlayer.getXRot());
            }
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
    }
}
