COHETE ESPACIAL - Minecraft Java 1.19.4 / Forge 45.4.1

Contenido:
- Item Cohete Espacial con textura pixel-art propia.
- Receta: I = lingote de hierro, R = bloque de redstone, F = cohete de fuegos artificiales.
- Al usar el cohete en el mundo normal, teletransporta al jugador a la dimensión space:moon.
- Al volver a usarlo en la Luna, regresa al Overworld.
- Dimensión lunar plana con suelo de hormigón gris, piedra y bedrock.

CAMBIOS (revision): corregido level() -> level (1.19.4), altura de aparicion en la Luna (y=-58), campos monster_spawn_* del dimension_type, agregado pack.mcmeta.

IMPORTANTE:
Este paquete contiene el PROYECTO FUENTE, no un .jar compilado. En el entorno donde se preparó no hay acceso a Internet para descargar ForgeGradle y sus dependencias, así que no es posible afirmar que el .jar se haya compilado ni probado aquí.

Para compilar en PC:
1. Instala Java JDK 17.
2. Abre esta carpeta en una terminal.
3. Ejecuta gradle genIntellijRuns (opcional) y luego gradle build.
4. El .jar se genera en build/libs/.
5. Copia el .jar a .minecraft/mods y ejecuta Minecraft 1.19.4 con Forge 45.4.1.

El proyecto usa ForgeGradle 6 y las dependencias oficiales de Forge; la primera compilación necesita Internet.

En el juego también puedes obtenerlo con:
/give @p space:rocket
